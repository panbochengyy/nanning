package com.zebra.common.exception;

/**
 * ip限制异常
 *
 * @author ruoyi
 */
public class LimitIpException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public LimitIpException() {

	}
}
