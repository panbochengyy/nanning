package com.zebra.common.exception;

/**
 * 缓存更新失败异常
 *
 * @author ruoyi
 */
public class CacheException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public CacheException() {

	}
}
