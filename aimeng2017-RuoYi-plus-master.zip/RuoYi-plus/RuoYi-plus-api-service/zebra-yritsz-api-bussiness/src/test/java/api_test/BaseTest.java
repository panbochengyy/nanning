package api_test;

public class BaseTest {
	/**
	 * heand头部key
	 */
	final static String KEY_HEAND = "hand_temple_key";
	/**
	 * key-表t_api_security
	 */
	final static String KEY = "key_2019xertybd66!2";
	/**
	 * 秘钥-表t_api_security
	 */
	final static String SECRET = "2134567897686";
}
